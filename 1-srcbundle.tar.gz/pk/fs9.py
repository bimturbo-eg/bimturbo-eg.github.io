import subprocess,json,time,urllib.request,websocket,base64,atexit,sys
url,wd,lang=sys.argv[1],int(sys.argv[2]),sys.argv[3]
ps=[]
p=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--no-sandbox','--disable-dev-shm-usage','--remote-allow-origins=*','--remote-debugging-port=9228','--user-data-dir=/tmp/chrome-fl','--allow-file-access-from-files','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--enable-webgl','about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
atexit.register(p.terminate)
for _ in range(40):
 try: tabs=json.load(urllib.request.urlopen('http://127.0.0.1:9228/json'));break
 except: time.sleep(.2)
w=websocket.create_connection(tabs[0]['webSocketDebuggerUrl'],max_size=None);i=0
def call(m,a={}):
 global i
 i+=1;w.send(json.dumps({'id':i,'method':m,'params':a}))
 while 1:
  r=json.loads(w.recv())
  if r.get('id')==i:return r.get('result',r)
def ev(s):return call('Runtime.evaluate',{'expression':s,'returnByValue':True}).get('result',{}).get('value')
call('Runtime.enable');call('Emulation.setDeviceMetricsOverride',{'width':wd,'height':900 if wd>600 else 800,'deviceScaleFactor':1,'mobile':wd<600})
call('Page.navigate',{'url':url});time.sleep(6)
if ev('document.documentElement.lang')!=lang:ev('document.querySelector("#lang").click()')
print('gl ok',ev('!!document.getElementById("gl").getContext("webgl2")||true'),'overflow',ev('document.documentElement.scrollWidth>innerWidth'),'flyh',ev('document.getElementById("fly").offsetHeight'))
for k in []:
 ev('window.scrollTo(0,(document.getElementById("fly").offsetHeight-innerHeight)*%f+document.getElementById("fly").offsetTop)'%k)
 time.sleep(3.2)
 r=call('Page.captureScreenshot',{'format':'jpeg','quality':70});open('/downloads/fl-%d-%s-%03d.jpg'%(wd,lang,int(k*100)),'wb').write(base64.b64decode(r['data']))



import time
for n,sel in enumerate(sys.argv[4].split(',')):
 ev('window.scrollTo(0,document.querySelector("%s").offsetTop+%d)'%(sel.split('@')[0],int(sel.split('@')[1])));time.sleep(9)
 r=call('Page.captureScreenshot',{'format':'jpeg','quality':70});open('/downloads/fs-%d-%s-%d.jpg'%(wd,lang,n),'wb').write(base64.b64decode(r['data']))
print('overflow',ev('document.documentElement.scrollWidth>innerWidth'))
p.terminate()
