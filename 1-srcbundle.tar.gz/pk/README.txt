Sources for the BIM Turbo / personal site scrollytelling.
t3/src: three.js engine sources (model_qtc2.js Qatar, model_hdy2.js Hudayriat, ksp2.js KSP). Build: npx esbuild src/entryH2.js --bundle --minify --format=iife --outfile=out/hdy2.js (entryQ2.js, entryK2.js likewise; needs npm i three esbuild).
t3/road.py + mask_raw.png: Hudayriat road texture generator.
p3: page files (h_bt2.html company, h_pe.html personal) and patch scripts.
dep2.sh: GitHub web-upload deploy helper. fs9.py: screenshot helper. No credentials are included.
