import sys
src,dst,js=sys.argv[1:4]
s=open(src).read()
EN='qb0:"Scroll to dive",qb1:"High detailing",qd1:"Utilities modeled in high detail.",qb2:"Coordination",qd2:"All services coordinated in one federated model.",qb3:"Clash solving",qd3:"Clashes between services found and resolved.",qb4:"Cope parameters",qd4:"Cope parameters set on the model elements. Zooming into one.",'
AR='qb0:"اسكرول وانزل",qb1:"تفاصيل عالية",qd1:"الخدمات متعملة بتفاصيل عالية.",qb2:"التنسيق",qd2:"كل الخدمات منسقة في موديل واحد.",qb3:"حل الكلاشات",qd3:"الكلاشات بين الخدمات بتتلاقي وبتتحل.",qb4:"Cope parameters",qd4:"الـ cope parameters متظبطة على عناصر الموديل. وهنقرب على واحد منهم.",'
a=s.find('q4:"');b=s.find('q4:"',a+1);assert a>0 and b>a
s=s[:b]+AR+s[b:];s=s[:a]+EN+s[a:]
css='''
.qb{position:absolute;z-index:3;inset-inline:max(24px,calc((100% - 1240px)/2));bottom:150px;pointer-events:none;height:140px}
.qb div{position:absolute;inset-inline-start:0;bottom:0;max-width:min(460px,86vw);opacity:0;will-change:transform,opacity;border-inline-start:3px solid currentColor;padding-inline-start:14px}
.qb small{font:700 .75rem monospace;letter-spacing:.25em;color:inherit;display:block}
.qb h3{font:900 clamp(1.8rem,4vw,3rem)/1 Impact,Arial,sans-serif;text-transform:uppercase;margin:6px 0 6px;color:#fff;text-shadow:0 2px 18px #000,0 0 40px #000}
[dir=rtl] .qb h3{font-family:Cairo,Tahoma,Arial,sans-serif;text-transform:none;line-height:1.15}
.qb p{margin:0;color:#e3e8df;line-height:1.55;text-shadow:0 2px 18px #000,0 0 30px #000}
.qrail{position:absolute;z-index:3;inset-inline-end:14px;top:50%;width:3px;height:120px;margin-top:-60px;background:rgba(255,255,255,.18);border-radius:2px;pointer-events:none}
.qrail i{display:block;width:100%;height:0;background:currentColor;border-radius:2px}
@media(max-width:700px){.qb{bottom:170px}}
'''
s=s.replace('</style>',css+'</style>',1)
html='<div class="qb" id="qb"><div><small data-k="qb0"></small><h3 data-k="qb1"></h3><p data-k="qd1"></p></div><div><small></small><h3 data-k="qb2"></h3><p data-k="qd2"></p></div><div><small></small><h3 data-k="qb3"></h3><p data-k="qd3"></p></div><div><small></small><h3 data-k="qb4"></h3><p data-k="qd4"></p></div></div><div class="qrail" id="qrail"><i></i></div>\n'
m='<div class="kstats" id="qstats">'
assert m in s
s=s.replace(m,html+m,1)
# JS: drive beats
old='onFrame:function(c,w){var W=cv.clientWidth,x=(w*1.2-.1)*W;scan.style.left=x+"px";scan.style.opacity=w>.02&&w<.98?1:0;t1.style.opacity=w>.1?1:.25;t2.style.opacity=w<.9?1:.25}}).then(function(a){if(!a)return;api=a;tri=a.stats.tris;st();'
assert old in s
new=old.replace('onFrame:function(c,w){','onFrame:function(c,w){beats(c);')
s=s.replace(old,new,1)
fn='''var qb=$$("#qb div"),qr=$("#qrail i"),qk=$(".qtc .kt"),B=[[.14,.33],[.35,.53],[.55,.72],[.76,.99]];
 try{var col=getComputedStyle($("#qtc .kt small")).color;$("#qb").style.color=col;$("#qrail").style.color=col}catch(e){}
 function ss(a,b,x){x=Math.max(0,Math.min(1,(x-a)/(b-a)));return x*x*(3-2*x)}
 function beats(c){for(var i=0;i<4;i++){var a=B[i][0],b=B[i][1],f=.07,o=ss(a,a+f,c)*(1-ss(b-f,b,c)),y=(1-ss(a,a+f,c))*26-ss(b-f,b,c)*26;qb[i].style.opacity=o;qb[i].style.transform="translateY("+y.toFixed(1)+"px)"}
  if(qk){qk.style.opacity=1-ss(.06,.14,c);qk.style.transform="translateY("+(-ss(.06,.14,c)*30).toFixed(1)+"px)"}qr.style.height=(c*100)+"%"}
 '''
k='/* Qatar model flythrough */\n(function(){var sec=$("#qtc"),cv=$("#qcv");if(!sec||!cv||document.documentElement.classList.contains("st"))return;\n var api=null,'
assert k in s
s=s.replace(k,k+fn.replace('\n ','\n ',0)+'',1) if False else s.replace(k,k.replace(' var api=null,',' ')+'var api=null,'+'',1)
# simpler: insert fn before 'function prog()' inside qtc block
i=s.find('/* Qatar model flythrough */');j=s.find(' function prog()',i)
s=s[:j]+' '+fn+s[j:]
import re
s=re.sub(r'<script src="\.?/?8-qtcjs\.js">',lambda m:m.group(0).replace('8-qtcjs.js',js),s,1)
open(dst,'w').write(s)
