import sys,re
src,dst,js,data=sys.argv[1:5]
s=open(src).read()
s=s.replace('<p class="knote" data-k="h4"></p>','').replace('<p class="knote" data-k="k4"></p>','')
html='<div class="qb" id="hqb"><div><small>01</small><h3 data-k="qb1"></h3><p data-k="qd1"></p></div><div><small>02</small><h3 data-k="qb2"></h3><p data-k="qd2"></p></div><div><small>03</small><h3 data-k="qb3"></h3><p data-k="qd3"></p></div></div><div class="qrail" id="hrail"><i></i></div>'
m='<div class="kstats" id="hstats">'
assert m in s; s=s.replace(m,html+m,1)
i=s.find('/* Hudayriat flight */');assert i>0
fn=''' var qb=$$("#hqb div"),qr=$("#hrail i"),qk=$("#hdy .kt"),B=[[.09,.2],[.24,.36],[.4,.58]];
 try{var col=getComputedStyle($("#hdy .kt small")).color;$("#hqb").style.color=col;$("#hrail").style.color=col}catch(e){}
 function ss(a,b,x){x=Math.max(0,Math.min(1,(x-a)/(b-a)));return x*x*(3-2*x)}
 function beats(c){for(var i=0;i<3;i++){var a=B[i][0],b=B[i][1],f=.05,o=ss(a,a+f,c)*(1-ss(b-f,b,c)),y=(1-ss(a,a+f,c))*26-ss(b-f,b,c)*26;qb[i].style.opacity=o;qb[i].style.transform="translateY("+y.toFixed(1)+"px)"}
  if(qk){qk.style.opacity=1-ss(.04,.1,c);qk.style.transform="translateY("+(-ss(.04,.1,c)*30).toFixed(1)+"px)"}qr.style.height=(c*100)+"%"}
'''
j=s.find(' function prog()',i);s=s[:j]+fn+s[j:]
old='onFrame:function(c,w){var W=cv.clientWidth'
k=s.find(old,i);assert k>0
s=s[:k]+'onFrame:function(c,w){beats(c);var W=cv.clientWidth'+s[k+len(old):]
s=re.sub(r'url:"\./?4-hdy\.bin\.gz"|url:"2-hdy\.bin\.gz"',lambda m:m.group(0),s)
s=s.replace('src="./1-9-hdy.js"','src="./%s"'%js).replace('src="1-9-hdy.js"','src="%s"'%js)
open(dst,'w').write(s)
