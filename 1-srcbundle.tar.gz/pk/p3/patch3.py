import re,sys
src,dst,acc=sys.argv[1:4]
h=open(src,encoding='utf-8').read()
def rep(a,b,c=1):
    global h
    assert h.count(a)>=1,a
    h=h.replace(a,b,c)
# images
rep('pimg(s[3],1100)','(SI[s[3]]!=null?im(SI[s[3]],1100):pimg(s[3],1100))')
rep("loading=\"lazy\" src=\"'+im(p.imgs[0],1100)+'\"></figure></div>'});\n  items.push([.955","loading=\"lazy\" src=\"'+im(PJ[p.id],1100)+'\"></figure></div>'});\n  items.push([.955")
m=re.search(r'var P=\[.*?\];\n',h,re.S)
h=h[:m.end()]+'var SI={kb:29,mh:65,hu:25,ez:20},PJ={ez:19,hu:24,kb:26,ne:37,am:50};(function(){var u=[];for(var k in SI)u.push(SI[k]);for(var k in PJ)u.push(PJ[k]);P.forEach(function(p){p.imgs=p.imgs.filter(function(n){return u.indexOf(n)<0})})})();\n'+h[m.end():]
# dividers
D=[('expertise','dv_ex','Expertise','الخبرات'),('work','dv_wk','Projects','المشاريع'),('product','dv_pr','The add-in','الأداة'),('lab','dv_lb','Tool kit','الأدوات'),('workflow','dv_wf','Workflow','طريقة الشغل'),('about','dv_ab','About','عني'),('education','dv_ed','Education','التعليم'),('certs','dv_ce','Certifications','الشهادات'),('contact','dv_ct','Contact','التواصل')]
en='';ar=''
for sid,k,e,a in D:
    mm=re.search(r'<section[^>]*\bid="%s"'%sid,h)
    assert mm,sid
    h=h[:mm.start()]+'<div class="dvd" id="d-%s"><span data-k="%s"></span></div>\n'%(sid,k)+h[mm.start():]
    en+='%s:"%s",'%(k,e);ar+='%s:"%s",'%(k,a)
rep('var T={\nen:{','var T={\nen:{\n'+en,1)
i=h.index('\nar:{',h.index('var T={'));h=h[:i]+'\nar:{\n'+ar+h[i+5:]
css='''
/* v4 dividers */
.dvd{position:relative;z-index:7;display:flex;align-items:center;gap:16px;padding:20px max(24px,calc((100% - 1240px)/2));background:#10161f;border-block:2px solid ACC;font:700 .85rem monospace;letter-spacing:.32em;text-transform:uppercase;color:#fff;direction:ltr}
[dir=rtl] .dvd{direction:rtl;font-family:Cairo,Tahoma,Arial,sans-serif;letter-spacing:0;font-size:1.05rem;text-transform:none}
.dvd:before{content:"";flex:none;width:12px;height:12px;background:ACC}
.dvd:after{content:"";flex:1;height:1px;background:rgba(200,210,225,.4)}
.dvd+.sec{padding-top:clamp(40px,5vw,80px)}
.sec:before,.qtc:before,.ksp:before,.statement:before{display:none}
.dvd+.sec,.dvd+.qtc{border-top:0}
'''.replace('ACC',acc)
rep('</style>',css+'</style>',1) if False else None
j=h.index('/* v3 fixes */'); k=h.index('</style>',j)
h=h[:k]+css+h[k:]

old="mi.style.opacity=0;setTimeout(function(){mi.src=im(p.imgs[i],1400);mi.dataset.n=i;mi.style.opacity=1},250);"
rep(old,"var uu=im(p.imgs[i],1400),pl=new Image();mi.dataset.n=i;pl.onload=pl.onerror=function(){mi.style.opacity=.2;setTimeout(function(){mi.src=uu;mi.style.opacity=1},80)};pl.src=uu;")
pre="""
<script>(function(){var seen={};function pre(a){var p=P.filter(function(x){return x.id===a.dataset.id})[0];if(!p||seen[p.id])return;seen[p.id]=1;p.imgs.forEach(function(n){var i=new Image();i.src=im(n,1400)})}
var io=window.IntersectionObserver?new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){pre(e.target);io.unobserve(e.target)}})},{rootMargin:"800px 0px"}):null;
function scan(){document.querySelectorAll("#projects .proj").forEach(function(a){if(io){if(!a._o){a._o=1;io.observe(a)}}else pre(a)})}
var pj=document.getElementById("projects");if(pj){new MutationObserver(scan).observe(pj,{childList:true});scan()}})();</script>
"""
rep('</body>',pre+'</body>',1)
rep('.dvd+.sec,.dvd+.qtc{border-top:0}','.dvd+.sec,.dvd+.qtc{border-top:0}\n.main-img img{transition:opacity .12s ease}')

open(dst,'w',encoding='utf-8').write(h)

