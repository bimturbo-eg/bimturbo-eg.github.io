import gzip,json,struct,numpy as np
raw=gzip.open('/tmp/p3/js/9-7-qtcdata.bin.gz').read()
hl=struct.unpack('<I',raw[:4])[0];H=json.loads(raw[4:4+hl]);off=4+hl
mn=np.array(H['min']);ex=np.array(H['max'])-mn
OX,OY=125,1100
A=[]
for gi,g in enumerate(H['groups']):
    nv,nt=g['nv'],g['nt']
    pv=np.frombuffer(raw,dtype='<u2',count=nv*3,offset=off).reshape(-1,3);off+=nv*6+nt*12
    p=pv/65535.0*ex
    A.append(np.c_[p[:,0]-OX,p[:,1]-OY+1100,p[:,2],np.full(nv,gi)])  # x east, yr along, z rel
V=np.vstack(A);np.save('/tmp/p3/V.npy',V)
print('z rel pct',np.percentile(V[:,2],[1,25,50,75,95,99,99.9]).round(2))
for y0 in range(0,2200,200):
    s=V[(V[:,1]>=y0)&(V[:,1]<y0+200)]
    print(y0,len(s),'zmax',s[:,2].max().round(1),'z p99',np.percentile(s[:,2],99).round(1),'z p50',np.percentile(s[:,2],50).round(1))
# group z ranges
for gi,g in enumerate(H['groups']):
    s=V[V[:,3]==gi];print(gi,g['name'],g['color'],'z',s[:,2].min().round(1),s[:,2].max().round(1),'x',s[:,0].min().round(0),s[:,0].max().round(0))
