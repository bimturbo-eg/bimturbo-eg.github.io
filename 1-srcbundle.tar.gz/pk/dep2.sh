# dep2.sh LEASE OWNER/REPO HTMLFILE   (assumes logged in; JS already uploaded)
L=$1; R=https://github.com/$2; H=$3
fnd(){ tools cloud_browser find --lease-id $L --tab-id 1 --query "$1" --json | jq -r "$2"; }
up(){ tools cloud_browser navigate --lease-id $L --tab-id 1 --url $R/upload/main >/dev/null; sleep 2
 for i in 1 2 3 4 5; do X=$(fnd 'Choose your files button' '[.[]|select(.text|test("Choose your files"))][0].ref'); out=$(tools cloud_browser upload-file --lease-id $L --tab-id 1 --ref $X --file-path $1 2>&1); echo "$out"|grep -q '"uploaded":true' && break; sleep 3; done
 sleep 20; C=$(fnd 'Commit changes button' '[.[]|select(.text=="Commit changes" and .role=="button")][0].ref'); tools cloud_browser click --lease-id $L --ref $C >/dev/null; sleep 8; }
ls_(){ tools cloud_browser navigate --lease-id $L --tab-id 1 --url $R/tree/main >/dev/null; tools cloud_browser read-page --lease-id $L --tab-id 1 --format text | grep -E "$1"; }
commit(){ B=$(fnd 'Commit changes... button' '[.[]|select(.text=="Commit changes...")][0].ref'); tools cloud_browser click --lease-id $L --ref $B >/dev/null; sleep 3
 D=$(fnd 'Commit changes button in dialog' '[.[]|select(.text=="Commit changes" and .role=="button")][0].ref'); echo D=$D; [ "$D" != null ] && tools cloud_browser click --lease-id $L --ref $D >/dev/null; sleep 6; }
case $4 in
 js) up $H; ls_ 'qtc';;
 html) up $H; ls_ 'index';;
 del) tools cloud_browser navigate --lease-id $L --tab-id 1 --url $R/delete/main/index.html >/dev/null; sleep 2; commit; ls_ 'index';;
 ren) tools cloud_browser navigate-and-read --lease-id $L --tab-id 1 --url $R/edit/main/$H > /tmp/e.txt
   T=$(grep -o 'textbox \\"File name\\"[^[]*\[ref=n[0-9]*\]' /tmp/e.txt | grep -o 'n[0-9]*\]' | tr -d ']'); tools cloud_browser form-input --lease-id $L --ref $T --value index.html >/dev/null; sleep 1; commit; ls_ 'index';;
esac
