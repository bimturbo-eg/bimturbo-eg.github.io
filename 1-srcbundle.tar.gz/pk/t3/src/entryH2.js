import {initModel} from './model_hdy2.js';window.initHDY=initModel;
