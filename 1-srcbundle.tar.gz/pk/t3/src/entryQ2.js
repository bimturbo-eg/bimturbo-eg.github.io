import {initModel} from './model_qtc2.js';window.initQTC=initModel;
