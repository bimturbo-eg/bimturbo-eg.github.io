import {initFly} from './scene.js';
window.initFly=initFly;
