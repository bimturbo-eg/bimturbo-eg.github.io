import {initKSP} from './ksp.js';window.initKSP=initKSP;
