import {initModel} from './model.js';window.initModel=initModel;
