import {initKSP} from './ksp2.js';window.initKSP=initKSP;
