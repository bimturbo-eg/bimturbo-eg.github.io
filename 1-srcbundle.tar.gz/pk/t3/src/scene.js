import {WebGLRenderer,Scene,PerspectiveCamera,FogExp2,Color,AmbientLight,PointLight,DirectionalLight,CylinderGeometry,TorusGeometry,BoxGeometry,SphereGeometry,PlaneGeometry,MeshStandardMaterial,MeshBasicMaterial,LineBasicMaterial,Mesh,LineSegments,EdgesGeometry,Group,Vector3,Quaternion,CatmullRomCurve3,BufferGeometry,Float32BufferAttribute,Points,PointsMaterial,DoubleSide,AdditiveBlending,GridHelper,MathUtils} from 'three';
const LIME=0xcaff2e,RED=0xff3b3b;
export function initFly(opts){
 const canvas=opts.canvas,host=opts.host;
 const mobile=matchMedia('(max-width:800px)').matches||/Android|iPhone|iPad/i.test(navigator.userAgent);
 let renderer;
 try{renderer=new WebGLRenderer({canvas,antialias:!mobile,alpha:false,powerPreference:'high-performance'})}catch(e){return null}
 renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,mobile?1.25:1.75));
 renderer.setClearColor(0x050505,1);
 const scene=new Scene();scene.fog=new FogExp2(0x050505,mobile?.011:.009);
 const cam=new PerspectiveCamera(62,1,.1,600);
 scene.add(new AmbientLight(0x99aabb,1.5));
 const dl=new DirectionalLight(0xffffff,.8);dl.position.set(20,40,10);scene.add(dl);
 const headlight=new PointLight(LIME,22,38,1.8);scene.add(headlight);
 const seg=mobile?12:20;
 const Y=new Vector3(0,1,0);
 const edgeMat=new LineBasicMaterial({color:LIME,transparent:true,opacity:.55});
 const world=new Group();scene.add(world);
 function pipe(a,b,r,color,opts2){
  opts2=opts2||{};
  const d=new Vector3().subVectors(b,a),len=d.length();
  const g=new CylinderGeometry(r,r,len,seg,1,false);
  const m=new MeshStandardMaterial(Object.assign({color:color,roughness:.45,metalness:.35,emissive:color,emissiveIntensity:.55},opts2.mat||{}));
  const me=new Mesh(g,m);me.position.copy(a).add(b).multiplyScalar(.5);
  me.quaternion.setFromUnitVectors(Y,d.clone().normalize());
  if(opts2.edges){const e=new LineSegments(new EdgesGeometry(g,20),opts2.edgeMat||edgeMat);me.add(e)}
  world.add(me);return me;
 }
 function ring(p,r,axis,color,t){
  const g=new TorusGeometry(r,t||.12,8,seg*2);const m=new MeshBasicMaterial({color:color,transparent:true,opacity:.8});
  const me=new Mesh(g,m);me.position.copy(p);
  if(axis==='z'){}else if(axis==='x')me.rotation.y=Math.PI/2;else me.rotation.x=Math.PI/2;
  world.add(me);return me;
 }
 const TY=-7,R=4.2,Z0=60,Z1=-250;
 // trunk tunnel: glass shell + lime edges + flange rings
 const shellGeo=new CylinderGeometry(R,R,Z0-Z1,seg*2,1,true);
 const shell=new Mesh(shellGeo,new MeshStandardMaterial({color:0x10201a,transparent:true,opacity:.22,side:DoubleSide,depthWrite:false,roughness:.3,metalness:.5}));
 shell.rotation.x=Math.PI/2;shell.position.set(0,TY,(Z0+Z1)/2);world.add(shell);
 const tLines=new LineSegments(new EdgesGeometry(new CylinderGeometry(R,R,Z0-Z1,16,1,true),20),new LineBasicMaterial({color:LIME,transparent:true,opacity:.5}));
 tLines.rotation.x=Math.PI/2;tLines.position.copy(shell.position);world.add(tLines);
 for(let z=Z0;z>=Z1;z-=10){ring(new Vector3(0,TY,z),R+.02,'z',LIME,.07)}
 for(const sx of [-2.4,2.4]){const st=new Mesh(new BoxGeometry(.16,.1,Z0-Z1),new MeshBasicMaterial({color:LIME}));st.position.set(sx,TY-R+.3,(Z0+Z1)/2);world.add(st)}
 // branches
 const cols=[0x3aa0ff,0xff8a3d,0xcaff2e,0x7be0ff,0xe9eef5];
 const clashes=[];
 for(let i=0,z=30;z>-245;z-=24,i++){
  const side=i%2?1:-1,y=TY+1+((i*37)%5)*.55,r=.32+((i*13)%5)*.11,c=cols[i%cols.length];
  const L=46;
  const a=new Vector3(-L,y,z),b=new Vector3(L,y,z);
  pipe(a,b,r,c,{edges:true,edgeMat:new LineBasicMaterial({color:c,transparent:true,opacity:.9})});
  // manhole shaft
  const sx=side*(L-6);
  pipe(new Vector3(sx,y,z),new Vector3(sx,0,z),r*1.5,0x2a2f33,{edges:true});
  ring(new Vector3(sx,.02,z),r*1.9,'y',LIME,.14);
  ring(new Vector3(-sx*.4,y,z),r*1.12,'x',c,.1);
 }
 // clash pipes (red -> lime)
 const clashMats=[0,1].map(()=>new MeshStandardMaterial({color:RED,emissive:RED,emissiveIntensity:.9,roughness:.4}));
 const clashRings=[0,1].map(()=>new MeshBasicMaterial({color:RED,transparent:true,opacity:.9}));
 [-96,-150].forEach(function(z,i){
  const m=new Mesh(new CylinderGeometry(1.1,1.1,12,seg,1,false),clashMats[i]);m.rotation.z=Math.PI/2;m.position.set(i?-1.5:1.5,TY+1.4,z);world.add(m);
  const t=new Mesh(new TorusGeometry(2.6,.08,8,seg*2),clashRings[i]);t.position.set(m.position.x,TY+1.4,z);world.add(t);clashes.push(t);
 });
 // surface plane + grid
 const gp=new Mesh(new PlaneGeometry(900,900),new MeshStandardMaterial({color:0x0b0e0c,transparent:true,opacity:.45,side:DoubleSide,depthWrite:false,roughness:1}));
 gp.rotation.x=-Math.PI/2;gp.position.set(0,0,-240);world.add(gp);
 const grid=new GridHelper(900,90,LIME,0x39422e);grid.material.transparent=true;
 world.add(grid);
 grid.position.set(0,.03,-240);grid.material.opacity=.6;
 // road centerline
 const road=new Mesh(new PlaneGeometry(9,640),new MeshBasicMaterial({color:0x1a1d1a,transparent:true,opacity:.9}));
 road.rotation.x=-Math.PI/2;road.position.set(0,.05,-260);world.add(road);
 // buildings
 const bGeo=new BoxGeometry(1,1,1),bMat=new MeshStandardMaterial({color:0x26302a,roughness:.8,metalness:.2});
 const eg=new EdgesGeometry(bGeo),el=new LineBasicMaterial({color:LIME,transparent:true,opacity:.55});
 let s=7;function rnd(){s=(s*16807)%2147483647;return s/2147483647}
 const nb=mobile?80:170;
 for(let i=0;i<nb;i++){
  const w=5+rnd()*11,d=5+rnd()*11,h=4+rnd()*rnd()*40;
  const x=(rnd()<.5?-1:1)*(10+rnd()*70),z=60-rnd()*560;
  const b=new Mesh(bGeo,bMat);b.scale.set(w,h,d);b.position.set(x,h/2,z);
  const l=new LineSegments(eg,el);b.add(l);world.add(b);
 }
 // particles
 const pc=mobile?250:600,pp=new Float32Array(pc*3);
 for(let i=0;i<pc;i++){pp[i*3]=(rnd()-.5)*30;pp[i*3+1]=TY+(rnd()-.5)*14;pp[i*3+2]=60-rnd()*310}
 const pg=new BufferGeometry();pg.setAttribute('position',new Float32BufferAttribute(pp,3));
 world.add(new Points(pg,new PointsMaterial({color:LIME,size:.18,transparent:true,opacity:.7,blending:AdditiveBlending,depthWrite:false})));
 // camera rails
 const CY=TY-1.7,P=[[0,34,84],[10,16,44],[3,-2,18],[0,CY+.6,-5],[.8,CY,-60],[-.8,CY,-120],[.6,CY,-190],[0,CY+.3,-232],[0,-3,-242],[0,12,-244],[0,22,-236],[0,26,-262],[-16,30,-310],[10,28,-370],[0,34,-430]];
 const Tg=[[0,-2,10],[0,-4,-20],[0,CY+.8,-40],[0,CY+.8,-90],[0,CY+.9,-150],[.4,CY+.8,-170],[0,CY+.6,-230],[0,0,-250],[0,8,-246],[0,2,-290],[0,4,-330],[0,6,-340],[0,8,-380],[0,8,-440],[0,10,-500]];
 const cP=new CatmullRomCurve3(P.map(function(a){return new Vector3(a[0],a[1],a[2])}),false,'catmullrom',.5);
 const cT=new CatmullRomCurve3(Tg.map(function(a){return new Vector3(a[0],a[1],a[2])}),false,'catmullrom',.5);
 const uEnd=(function(){const q=new Vector3(0,22,-236);let bu=.5,bd=1e9;for(let i=0;i<=800;i++){const u=i/800,d=cP.getPointAt(u).distanceTo(q);if(d<bd){bd=d;bu=u}}return bu})();
 let target=0,cur=0,vel=0,mx=0,my=0,running=false,visible=true,last=0,hud=opts.onFrame;
 function size(){const w=innerWidth,h=innerHeight;renderer.setSize(w,h,false);cam.aspect=w/h;cam.fov=w/h<1?78:62;cam.updateProjectionMatrix()}
 size();addEventListener('resize',size);
 addEventListener('pointermove',function(e){mx=e.clientX/innerWidth-.5;my=e.clientY/innerHeight-.5},{passive:true});
 const sm=MathUtils.smoothstep,tmp=new Vector3(),tmp2=new Vector3();
 function frame(t){
  if(!running)return;requestAnimationFrame(frame);
  const r=opts.progress();target=r;vel=(vel+(target-cur)*.010)*.89;cur=Math.max(0,Math.min(2,cur+vel));
  const u=Math.min(.999,cur<=1?cur*uEnd:uEnd+(cur-1)*(1-uEnd));
  cP.getPointAt(u,tmp);cT.getPointAt(u,tmp2);
  tmp.x+=mx*.8+Math.sin(cur*40)*.12*(cur<1?1:.2);tmp.y+=-my*.5+Math.sin(cur*27)*.1;
  cam.position.copy(tmp);cam.lookAt(tmp2);cam.rotateZ(Math.sin(cur*16)*.045-mx*.05+vel*-6);const bf=(w0=>w0<1?78:62)(cam.aspect);cam.fov=bf+Math.sin(cur*10)*2+Math.min(8,Math.abs(vel)*900);cam.updateProjectionMatrix();
  headlight.position.copy(tmp).add(new Vector3(0,.5,-3));
  const k=0;
  [[60,92],[115,146]].forEach(function(r,i){const c=new Color(RED).lerp(new Color(LIME),sm(-tmp.z,r[0],r[1]));clashMats[i].color.copy(c);clashMats[i].emissive.copy(c);clashRings[i].color.copy(c)});
  const pulse=1+Math.sin(t*.004)*.08*(1-k);clashes.forEach(function(c){c.scale.set(pulse,pulse,1)});
  renderer.render(scene,cam);
  if(hud)hud(cur,cam.position);
 }
 return {
  start:function(){if(!running){running=true;requestAnimationFrame(frame)}},
  stop:function(){running=false},
  renderOnce:function(){running=true;frame(0);running=false},
  resize:size
 };
}
