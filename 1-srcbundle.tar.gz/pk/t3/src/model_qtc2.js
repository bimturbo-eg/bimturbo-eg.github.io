import {WebGLRenderer,Scene,PerspectiveCamera,Fog,Color,HemisphereLight,DirectionalLight,MeshStandardMaterial,MeshBasicMaterial,MeshLambertMaterial,Mesh,BufferGeometry,BufferAttribute,Float32BufferAttribute,Vector3,Plane,SphereGeometry,PlaneGeometry,BackSide,DoubleSide,CatmullRomCurve3,PMREMGenerator,MathUtils,ACESFilmicToneMapping,CanvasTexture,RepeatWrapping,LineSegments,WireframeGeometry,LineBasicMaterial} from 'three';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
// local origin (metres, relative to model min corner) and path, east/north/elevation
const OX=125,OY=1100;const GZ=[[87,15],[252,15.6],[471,15.6],[634,14.6],[853,14.6],[979,14.6],[1198,13.6],[1366,11.6],[1587,10.6],[1723,10.6],[1923,9.6],[2107,10.6]];
const gz=y=>{if(y<=GZ[0][0])return GZ[0][1];for(let i=1;i<GZ.length;i++)if(y<=GZ[i][0]){const a=GZ[i-1],b=GZ[i];return a[1]+(b[1]-a[1])*(y-a[0])/(b[0]-a[0])}return GZ[GZ.length-1][1]};
const CX=yr=>{const K=[[0,8.8],[300,-13],[500,4],[700,0],[900,-3],[1100,-5],[1300,-18],[1500,-19],[1700,-24],[1900,-28],[2150,-32]];if(yr<=0)return 8.8;for(let i=1;i<K.length;i++)if(yr<=K[i][0]){const a=K[i-1],b=K[i];return a[1]+(b[1]-a[1])*(yr-a[0])/(b[0]-a[0])}return -32};
const MH={e:-27.1,yr:353,y:13.1};
// scrollytelling path: [u, e offset from road centre, yr, height above ground (<0 = underground)]
const KF=[[0.0,2.5,2200,2.4],[0.096,2,1950,2.2],[0.2,4,1750,-3.4],[0.32,6,1350,-3.2],[0.44,7,950,-2.4],[0.544,6,650,-2.2],[0.624,8,470,-2.0],[0.704,-8,395,-1.4],[0.8,-18,366,-1.2],[0.88,-18,366,-1.2],[0.95,-6,430,70],[1,0,520,190]];
const PATH=null;
const REAL={cable:[0x1b1b1f,.35,0],hv:[0x9c1c1c,.35,0],duct:[0x908d85,.9,0],pipe:[0x7f8d96,.5,.2],structure:[0xa5a29a,.85,0]};
export async function initModel(o){
 const mobile=matchMedia('(max-width:800px)').matches;
 let r;try{r=new WebGLRenderer({canvas:o.canvas,antialias:!mobile,alpha:false})}catch(e){return null}
 r.setPixelRatio(Math.min(devicePixelRatio||1,mobile?1.25:1.6));r.localClippingEnabled=true;r.toneMapping=ACESFilmicToneMapping;r.toneMappingExposure=.85;
 const sc=new Scene();const cam=new PerspectiveCamera(55,1,.3,9000);
 const pm=new PMREMGenerator(r);sc.environment=pm.fromScene(new RoomEnvironment(),.04).texture;sc.environmentIntensity=.4;
 const pl=new Plane(),nl=new Plane();
 // sky domes (nav: dark engineering gradient, real: daylight)
 function dome(top,bot,clip){const g=new SphereGeometry(6000,24,16),c=[];const p=g.attributes.position;const ct=new Color(top),cb=new Color(bot),t=new Color();
  for(let i=0;i<p.count;i++){const k=MathUtils.clamp((p.getY(i)/6000+.15)/.9,0,1);t.copy(cb).lerp(ct,Math.pow(k,.7));c.push(t.r,t.g,t.b)}
  g.setAttribute('color',new Float32BufferAttribute(c,3));
  const m=new Mesh(g,new MeshBasicMaterial({vertexColors:true,side:BackSide,fog:false,depthWrite:false,clippingPlanes:[clip]}));m.renderOrder=-10;sc.add(m);return m}
 dome(0x2c3a52,0x0b0f16,nl);const sky=dome(0x5f9bd6,0xdfe9f2,pl);
 sc.fog=new Fog(0xcfc4ac,160,1700);
 sc.add(new HemisphereLight(0xdfeeff,0x6b5a45,.7));const sun=new DirectionalLight(0xfff1d6,2.6);sun.position.set(-400,700,300);sc.add(sun);
 const buf=await (await fetch(o.url)).arrayBuffer();
 const b8=new Uint8Array(buf);const raw=(b8[0]===0x1f&&b8[1]===0x8b)?new Uint8Array(await new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer()):b8;
 const dv=new DataView(raw.buffer);const hl=dv.getUint32(0,true);const H=JSON.parse(new TextDecoder().decode(raw.subarray(4,4+hl)));
 let off=4+hl;const mn=H.min,ex=[H.max[0]-H.min[0],H.max[1]-H.min[1],H.max[2]-H.min[2]];
 const stats={tris:0,objs:H.objs||0};const groups={};
 for(const g of H.groups){
  const nvb=g.nv*6,ntb=g.nt*12;const pv=new Uint16Array(raw.buffer.slice(raw.byteOffset+off,raw.byteOffset+off+nvb));off+=nvb;
  const ix=new Uint32Array(raw.buffer.slice(raw.byteOffset+off,raw.byteOffset+off+ntb));off+=ntb;
  const pos=new Float32Array(g.nv*3);
  for(let i=0;i<g.nv;i++){const x=pv[i*3]/65535*ex[0]-OX,n=pv[i*3+1]/65535*ex[1]-OY,z=pv[i*3+2]/65535*ex[2];pos[i*3]=x;pos[i*3+1]=z;pos[i*3+2]=-n}
  const geo=new BufferGeometry();geo.setAttribute('position',new BufferAttribute(pos,3));geo.setIndex(new BufferAttribute(ix,1));geo.computeVertexNormals();
  stats.tris+=g.nt;groups[g.name+'|'+g.color]=geo;
 }
 const meshes=[];let gp=null;
 {const pg=new PlaneGeometry(24000,24000);pg.rotateX(-Math.PI/2);const soil=new Mesh(pg,new MeshStandardMaterial({color:0x7a6347,roughness:1,clippingPlanes:[pl]}));soil.position.y=2.5;sc.add(soil);
  const ns=new Mesh(pg,new MeshBasicMaterial({color:0x0b1019,fog:false,clippingPlanes:[nl]}));ns.position.y=2.5;sc.add(ns)}
 for(const [key,geo] of Object.entries(groups)){
  const [name,hx]=key.split('|');const ncol=parseInt(hx,16)||0x8899aa;
  const nav=new Mesh(geo,new MeshLambertMaterial({color:ncol,fog:false,clippingPlanes:[nl],emissive:ncol,emissiveIntensity:.45}));sc.add(nav);
  const [col,ro,me]=REAL[name]||REAL.duct;
  const tint=new Color(col);if(name==='cable'){tint.lerp(new Color(ncol),.22)}
  const re=new Mesh(geo,new MeshStandardMaterial({color:tint,roughness:ro,metalness:me,flatShading:name!=='cable',clippingPlanes:[pl]}));sc.add(re);
 }
 // ground strip following the road, sand texture (real) / dark slab (nav)
 {const cv=document.createElement('canvas');cv.width=cv.height=256;const x=cv.getContext('2d');x.fillStyle='#c8b189';x.fillRect(0,0,256,256);
  for(let i=0;i<5000;i++){const v=150+Math.random()*90|0;x.fillStyle='rgba('+v+','+(v-18)+','+(v-55)+','+(.25+Math.random()*.35)+')';x.fillRect(Math.random()*256,Math.random()*256,1+Math.random()*2,1+Math.random()*2)}
  const tx=new CanvasTexture(cv);tx.wrapS=tx.wrapT=RepeatWrapping;tx.repeat.set(60,420);tx.anisotropy=4;
  const gg=new PlaneGeometry(420,2500,30,250);gg.rotateX(-Math.PI/2);const p=gg.attributes.position;
  for(let i=0;i<p.count;i++){const yr=OY-p.getZ(i);p.setY(i,gz(yr)+Math.sin(p.getX(i)*.05+yr*.03)*.15)}
  gg.translate(0,0,-0);gg.computeVertexNormals();
  gp=new Mesh(gg,new MeshStandardMaterial({map:tx,roughness:1,transparent:true,opacity:.42,side:DoubleSide,depthWrite:false,clippingPlanes:[pl]}));gp.position.set(0,0,-(1100-1250+100));gp.renderOrder=2;sc.add(gp);
  const gn=new Mesh(gg,new MeshBasicMaterial({color:0x26324a,transparent:true,opacity:.5,fog:false,side:DoubleSide,depthWrite:false,clippingPlanes:[nl]}));gn.position.copy(gp.position);gn.renderOrder=2;sc.add(gn)}

 // road surface on top of the corridor: asphalt ribbon, edge lines, dashed centre line (illustrative)
 const fadeMats=[];
 {const seg=140,Y0=-100,Y1=2300,W=13;const pos2=[],idx=[];for(let i=0;i<=seg;i++){const yr=Y0+(Y1-Y0)*i/seg,c=CX(yr),y=gz(yr)+.08,z=1100-yr;pos2.push(c-W/2,y,z,c+W/2,y,z)}
  for(let i=0;i<seg;i++){const a=i*2;idx.push(a,a+1,a+2,a+1,a+3,a+2)}
  const rg=new BufferGeometry();rg.setAttribute('position',new Float32BufferAttribute(pos2,3));rg.setIndex(idx);rg.computeVertexNormals();
  const rm=new MeshStandardMaterial({color:0x2b2d31,roughness:.95,transparent:true,side:DoubleSide,clippingPlanes:[pl],polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});const road=new Mesh(rg,rm);road.renderOrder=3;sc.add(road);fadeMats.push([rm,1]);
  const rn=new MeshBasicMaterial({color:0x1a2236,transparent:true,side:DoubleSide,fog:false,clippingPlanes:[nl]});const roadN=new Mesh(rg,rn);roadN.renderOrder=3;sc.add(roadN);fadeMats.push([rn,1]);
  const mk=(off,w,dash,col)=>{const p3=[],ix=[];let n=0;const step=6;for(let yr=Y0;yr<Y1;yr+=step){if(dash&&((yr-Y0)/step|0)%2)continue;const y2=yr+step*(dash?.55:1.02),c1=CX(yr)+off,c2=CX(y2)+off,ya=gz(yr)+.14,yb=gz(y2)+.14;p3.push(c1-w,ya,1100-yr,c1+w,ya,1100-yr,c2-w,yb,1100-y2,c2+w,yb,1100-y2);ix.push(n,n+1,n+2,n+1,n+3,n+2);n+=4}
   const g=new BufferGeometry();g.setAttribute('position',new Float32BufferAttribute(p3,3));g.setIndex(ix);g.computeVertexNormals();
   const m=new MeshBasicMaterial({color:col,transparent:true,side:DoubleSide,fog:false,clippingPlanes:[pl],polygonOffset:true,polygonOffsetFactor:-4,polygonOffsetUnits:-4});const me=new Mesh(g,m);me.renderOrder=4;sc.add(me);fadeMats.push([m,1])};
  mk(0,.12,true,0xf2f2f2);mk(-W/2+.6,.1,false,0xeeeeee);mk(W/2-.6,.1,false,0xeeeeee);
  // street-light style markers along the road edge (illustrative, so the road reads as a road)
  const pg2=new BufferGeometry(),pp=[],pi=[];let q=0;for(let yr=0;yr<2200;yr+=45){const c=CX(yr)+W/2+1.2,y=gz(yr),z=1100-yr,hh=7.5;pp.push(c-.12,y,z-.12,c+.12,y,z-.12,c+.12,y,z+.12,c-.12,y,z+.12,c-.12,y+hh,z-.12,c+.12,y+hh,z-.12,c+.12,y+hh,z+.12,c-.12,y+hh,z+.12);
   for(const f of [[0,1,5],[0,5,4],[1,2,6],[1,6,5],[2,3,7],[2,7,6],[3,0,4],[3,4,7]])pi.push(q+f[0],q+f[1],q+f[2]);q+=8}
  pg2.setAttribute('position',new Float32BufferAttribute(pp,3));pg2.setIndex(pi);pg2.computeVertexNormals();
  const pm2=new MeshStandardMaterial({color:0x8d949c,roughness:.5,metalness:.4,transparent:true,clippingPlanes:[pl]});const poles=new Mesh(pg2,pm2);poles.renderOrder=3;sc.add(poles);fadeMats.push([pm2,1]);
 }
 // path
 const KP=KF.map(k=>{const yr=k[2];return new Vector3(CX(yr)+k[1],gz(yr)+k[3],1100-yr)});const curve=new CatmullRomCurve3(KP,false,"centripetal");const KU=KF.map(k=>k[0]);
 function tu(u){for(let i=1;i<KU.length;i++)if(u<=KU[i])return (i-1+(u-KU[i-1])/(KU[i]-KU[i-1]))/(KU.length-1);return 1}
 const look=new Vector3(),pos=new Vector3(),fw=new Vector3(),rt=new Vector3(),up=new Vector3(0,1,0);
 function size(){const w=o.host.clientWidth||innerWidth,h=o.host.clientHeight||innerHeight;r.setSize(w,h,false);cam.aspect=w/h;cam.fov=w/h<1?75:55;cam.updateProjectionMatrix()}
 size();addEventListener('resize',size);
 let run=false,cur=0;const sm=MathUtils.smoothstep;
 function frame(){
  if(!run)return;requestAnimationFrame(frame);
  const p=window.__P!=null?window.__P:o.progress();cur+=(p-cur)*.08;if(window.__P!=null)cur=p;
  const u=MathUtils.clamp(cur,0,.999);
  curve.getPoint(tu(u),pos);curve.getPoint(Math.min(1,tu(Math.min(1,u+.045))),look);
  look.y=pos.y+(look.y-pos.y)*.35-(.4+2.2*(1-sm(u,.1,.3)))*0+ (u<.2?-1.2*sm(u,.0,.2):0);
  const zm=sm(u,.66,.78)*(1-sm(u,.86,.97));look.x+=(MH.e-look.x)*zm;look.y+=(MH.y-look.y)*zm;look.z+=((1100-MH.yr)-look.z)*zm;{const pz=sm(u,.86,.97),pyr=1100-pos.z,gyy=gz(pyr-30);look.x+=((CX(pyr-30))-look.x)*pz;look.y+=(gyy-look.y)*pz;look.z+=((pos.z+30)-look.z)*pz}
  if(window.__CAM){const c=window.__CAM;pos.set(c[0],c[1],c[2]);look.set(c[3],c[4],c[5])}
  const gy=gz(1100-pos.z);const fd=sm(pos.y-gy,-2.2,1.4);for(const f of fadeMats)f[0].opacity=.1+.9*fd;gp.material.opacity=.42*(.15+.85*fd);
  if(window.__CAM){const c=window.__CAM;pos.set(c[0],c[1],c[2]);look.set(c[3],c[4],c[5])}
  pos.y+=Math.sin(u*9)*.15;cam.position.copy(pos);cam.lookAt(look);cam.updateMatrixWorld();
  // wipe: nav -> real, left to right
  const w=Math.min(1,1-sm(cur,.25,.5)+sm(cur,.9,1));const a=(-1.2+2.4*w)*Math.tan(MathUtils.degToRad(cam.fov/2))*cam.aspect;
  cam.getWorldDirection(fw);rt.crossVectors(fw,up).normalize();
  const n=rt.clone().addScaledVector(fw,-a).normalize();
  nl.setFromNormalAndCoplanarPoint(n,pos);pl.setFromNormalAndCoplanarPoint(n.clone().negate(),pos);
  // plane keeps >=0 side: real = left of line => normal points left
  if(o.onFrame)o.onFrame(cur,w);
  r.render(sc,cam);
 }
 return {stats,start(){if(!run){run=true;requestAnimationFrame(frame)}},stop(){run=false},renderOnce(){run=true;frame();run=false}};
}
