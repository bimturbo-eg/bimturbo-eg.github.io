import {WebGLRenderer,Scene,PerspectiveCamera,Fog,Color,AmbientLight,DirectionalLight,CylinderGeometry,SphereGeometry,ConeGeometry,TorusGeometry,PlaneGeometry,MeshStandardMaterial,MeshBasicMaterial,Mesh,InstancedMesh,Object3D,Vector3,BufferGeometry,Float32BufferAttribute,Points,PointsMaterial,AdditiveBlending,GridHelper,MathUtils,DoubleSide} from 'three';
const LIME=0xcaff2e,WATER=0x38b6ff;
export function initKSP(o){
 const mobile=matchMedia('(max-width:800px)').matches;
 let r;try{r=new WebGLRenderer({canvas:o.canvas,antialias:!mobile,alpha:true})}catch(e){return null}
 r.setPixelRatio(Math.min(devicePixelRatio||1,mobile?1.25:1.75));r.setClearColor(0x050505,1);
 const sc=new Scene();sc.fog=new Fog(0x050505,70,230);
 const cam=new PerspectiveCamera(50,1,.5,500);
 sc.add(new AmbientLight(0x9fb0a0,1.4));const dl=new DirectionalLight(0xffffff,1.1);dl.position.set(40,80,30);sc.add(dl);
 let s=11;const rnd=()=>{s=(s*16807)%2147483647;return s/2147483647};
 const D=new Object3D(),Y=new Vector3(0,1,0);
 const LAT=mobile?9:13,XS=mobile?12:9,ZH=40,YL=-1.2,YM=-1.8;
 const xs=[];for(let i=0;i<LAT;i++)xs.push((i-(LAT-1)/2)*XS);
 const XW=xs[LAT-1]+8;
 const mat=(c,e)=>new MeshStandardMaterial({color:c,emissive:c,emissiveIntensity:e,roughness:.5,metalness:.3});
 // counts
 const cnt={pipes:0,sprk:0,bub:0,drip:0};
 // main pipe
 const main=new Mesh(new CylinderGeometry(.9,.9,XW*2,16),mat(0x2f7fd0,.5));main.rotation.z=Math.PI/2;main.position.set(0,YM,0);sc.add(main);cnt.pipes++;
 // laterals as instanced segments
 const SEG=4,nSeg=Math.floor(ZH*2/SEG);
 const lat=new InstancedMesh(new CylinderGeometry(.32,.32,SEG,8),mat(WATER,.6),LAT*nSeg);let k=0;
 xs.forEach(x=>{for(let j=0;j<nSeg;j++){D.position.set(x,YL,-ZH+SEG*(j+.5));D.rotation.set(Math.PI/2,0,0);D.scale.set(1,1,1);D.updateMatrix();lat.setMatrixAt(k++,D.matrix)}
  const ri=new Mesh(new CylinderGeometry(.5,.5,YL-YM,8),mat(0x2f7fd0,.5));ri.position.set(x,(YL+YM)/2,0);sc.add(ri)});
 sc.add(lat);cnt.pipes+=LAT*nSeg+LAT;
 // trees, branches, bubblers, drippers
 const tp=[];xs.forEach(x=>{for(let z=-ZH+3;z<=ZH-3;z+=5){[-1,1].forEach(sd=>{if(rnd()<.12)return;tp.push([x+sd*(2.6+rnd()*.6),z+(rnd()-.5)*1.2,sd,x])})}});
 const N=tp.length;
 const br=new InstancedMesh(new CylinderGeometry(.14,.14,1,6),mat(WATER,.5),N);
 const rs=new InstancedMesh(new CylinderGeometry(.14,.14,YL*-1,6),mat(WATER,.5),N);
 const bb=new InstancedMesh(new TorusGeometry(.5,.08,6,14),mat(LIME,.9),N);
 const trunk=new InstancedMesh(new CylinderGeometry(.2,.3,2.2,6),new MeshStandardMaterial({color:0x4a3a2a,roughness:.9}),N);
 const crown=new InstancedMesh(new SphereGeometry(1.7,10,8),new MeshStandardMaterial({color:0x2d6a3a,emissive:0x0d2a14,roughness:.8,transparent:true,opacity:.5,depthWrite:false}),N);
 const dr=new InstancedMesh(new SphereGeometry(.11,6,6),mat(LIME,1),N*4);let di=0;
 tp.forEach((t,i)=>{const [tx,tz,sd,lx]=t;
  const L=Math.abs(tx-lx);D.rotation.set(0,0,Math.PI/2);D.scale.set(1,L,1);D.position.set((tx+lx)/2,YL,tz);D.updateMatrix();br.setMatrixAt(i,D.matrix);
  D.rotation.set(0,0,0);D.scale.set(1,1,1);D.position.set(tx,YL/2-.0,tz);D.updateMatrix();rs.setMatrixAt(i,D.matrix);
  D.rotation.set(Math.PI/2,0,0);D.position.set(tx,.12,tz);D.updateMatrix();bb.setMatrixAt(i,D.matrix);
  D.rotation.set(0,0,0);D.position.set(tx,1.1,tz);D.updateMatrix();trunk.setMatrixAt(i,D.matrix);
  const sz=.55+rnd()*.35;D.scale.set(sz,sz,sz);D.position.set(tx,3.4,tz);D.updateMatrix();crown.setMatrixAt(i,D.matrix);D.scale.set(1,1,1);
  for(let q=0;q<4;q++){const a=q*Math.PI/2+.4;D.position.set(tx+Math.cos(a)*1.3,.1,tz+Math.sin(a)*1.3);D.updateMatrix();dr.setMatrixAt(di++,D.matrix)}});
 [br,rs,bb,trunk,crown,dr].forEach(m=>sc.add(m));
 cnt.pipes+=N*2;cnt.bub=N;cnt.drip=N*4;
 // sprinklers between laterals
 const sp=[];for(let i=0;i<LAT;i++){for(let z=-ZH+6;z<=ZH-6;z+=9){sp.push([xs[i]+(i%2?-1:1)*XS*.5*0+XS*.5-.0,z])}}
 const sH=new InstancedMesh(new CylinderGeometry(.22,.22,1,8),mat(0xe9eef5,.4),sp.length);
 const sB=new InstancedMesh(new CylinderGeometry(.14,.14,1,6),mat(WATER,.5),sp.length);
 sp.forEach((p,i)=>{const lx=p[0]-XS*.5;D.rotation.set(0,0,0);D.scale.set(1,.9,1);D.position.set(p[0],.45,p[1]);D.updateMatrix();sH.setMatrixAt(i,D.matrix);
  D.rotation.set(0,0,Math.PI/2);D.scale.set(1,XS*.5,1);D.position.set(lx+XS*.25,YL,p[1]);D.updateMatrix();sB.setMatrixAt(i,D.matrix);
  D.rotation.set(0,0,0);D.scale.set(1,1,1);D.position.set(p[0],(YL+.2)/2,p[1]);D.scale.set(1,(.2-YL)/1,1);D.updateMatrix();});
 sc.add(sH,sB);cnt.sprk=sp.length;cnt.pipes+=sp.length;
 // ground
 const gm=new MeshStandardMaterial({color:0x0f1a12,transparent:true,opacity:.9,roughness:1,side:DoubleSide,depthWrite:false});
 const ground=new Mesh(new PlaneGeometry(XW*2+40,ZH*2+40),gm);ground.rotation.x=-Math.PI/2;sc.add(ground);
 const grid=new GridHelper(XW*2+40,Math.round((XW*2+40)/6),LIME,0x2b3a22);grid.position.y=.02;grid.material.transparent=true;grid.material.opacity=.35;sc.add(grid);
 // water flow particles
 const FP=mobile?500:1400,fp=new Float32Array(FP*3),fm=[];
 for(let i=0;i<FP;i++){fm.push({l:Math.floor(rnd()*LAT),t:rnd(),d:rnd()<.5?-1:1,v:.15+rnd()*.15,ph:rnd()})}
 const fg=new BufferGeometry();fg.setAttribute('position',new Float32BufferAttribute(fp,3));
 sc.add(new Points(fg,new PointsMaterial({color:0xbfeaff,size:.45,transparent:true,opacity:.95,blending:AdditiveBlending,depthWrite:false})));
 // spray droplets
 const PER=mobile?4:7,SP=sp.length*PER,sa=new Float32Array(SP*3),sg=new BufferGeometry();sg.setAttribute('position',new Float32BufferAttribute(sa,3));
 sc.add(new Points(sg,new PointsMaterial({color:0x9fe0ff,size:.28,transparent:true,opacity:.85,blending:AdditiveBlending,depthWrite:false})));
 const dir=sp.map(()=>rnd()*6.28);
 function size(){const w=o.host.clientWidth||innerWidth,h=o.host.clientHeight||innerHeight;r.setSize(w,h,false);cam.aspect=w/h;cam.fov=w/h<1?68:50;cam.updateProjectionMatrix()}
 size();addEventListener('resize',size);
 let run=false,cur=0;const sm=MathUtils.smoothstep,tg=new Vector3();
 function frame(t){
  if(!run)return;requestAnimationFrame(frame);
  const p=o.progress();cur+=(p-cur)*.06;const T=t*.001;
  // particles
  for(let i=0;i<FP;i++){const f=fm[i];f.t=(f.t+f.v*.004)%1;const lx=xs[f.l];
   if(f.t<.35){const u=f.t/.35;fp[i*3]=lx*u;fp[i*3+1]=YM+(YL-YM)*0;fp[i*3+2]=0;fp[i*3+1]=YM}
   else{const u=(f.t-.35)/.65;fp[i*3]=lx;fp[i*3+1]=YL+(f.ph-.5)*.3;fp[i*3+2]=f.d*u*ZH}}
  fg.attributes.position.needsUpdate=true;
  for(let i=0;i<sp.length;i++)for(let q=0;q<PER;q++){const ph=((T*.9+q/PER+i*.13)%1),a=dir[i]+q*(6.28/PER),R=ph*3.6,h=Math.sin(ph*Math.PI)*2.6+.5,j=(i*PER+q)*3;sa[j]=sp[i][0]+Math.cos(a)*R;sa[j+1]=h;sa[j+2]=sp[i][1]+Math.sin(a)*R}
  sg.attributes.position.needsUpdate=true;
  // camera: aerial -> cutaway underground fly
  const a=-.6+cur*2.4,rad=118-cur*62,hgt=78-sm(cur,0,.8)*66;
  tg.set(Math.sin(cur*3)*8,sm(cur,.2,1)*-1.2,Math.sin(cur*5)*6);
  cam.position.set(Math.sin(a)*rad,hgt,Math.cos(a)*rad*.8);cam.lookAt(tg);
  gm.opacity=.92-sm(cur,.15,.55)*.82;grid.material.opacity=.35*(1-sm(cur,.2,.5));
  crown.visible=trunk.visible=cur<.7||true;
  r.render(sc,cam);o.onFrame&&o.onFrame(cur);
 }
 return {stats:cnt,start(){if(!run){run=true;requestAnimationFrame(frame)}},stop(){run=false},renderOnce(){run=true;frame(0);run=false}};
}
