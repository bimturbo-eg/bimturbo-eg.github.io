import {initModel} from './model.js';window.initHDY=initModel;
