import {Shape,ShapeGeometry,Line,LineBasicMaterial,WebGLRenderer,Scene,PerspectiveCamera,Fog,Color,AmbientLight,DirectionalLight,CylinderGeometry,SphereGeometry,ConeGeometry,TorusGeometry,PlaneGeometry,MeshStandardMaterial,MeshBasicMaterial,Mesh,InstancedMesh,Object3D,Vector3,BufferGeometry,Float32BufferAttribute,Points,PointsMaterial,AdditiveBlending,GridHelper,MathUtils,DoubleSide} from 'three';
const LIME=0xcaff2e,WATER=0x38b6ff;
const POLY=[[-0.5, -0.0419], [-0.4787, -0.0864], [-0.466, -0.1077], [-0.4079, -0.1772], [-0.3919, -0.1887], [-0.3703, -0.2002], [-0.274, -0.2486], [-0.257, -0.2563], [-0.242, -0.2641], [-0.2307, -0.2665], [-0.2198, -0.2719], [-0.2191, -0.271], [-0.2122, -0.2717], [-0.207, -0.2736], [-0.2074, -0.2764], [-0.1636, -0.2915], [-0.1613, -0.291], [-0.0979, -0.3131], [-0.0946, -0.3153], [-0.0403, -0.3343], [-0.0298, -0.3312], [-0.0283, -0.3279], [-0.0242, -0.327], [-0.02, -0.3265], [-0.0175, -0.3276], [-0.0171, -0.3308], [-0.0139, -0.3378], [-0.0117, -0.3389], [-0.0092, -0.3396], [0.0013, -0.3409], [0.0166, -0.3454], [0.0219, -0.3484], [0.0365, -0.3606], [0.0413, -0.3629], [0.0451, -0.3636], [0.0487, -0.3619], [0.0532, -0.3731], [0.0582, -0.3777], [0.0612, -0.3883], [0.0607, -0.41], [0.0683, -0.4546], [0.0699, -0.4736], [0.0704, -0.507], [0.071, -0.5082], [0.0719, -0.5087], [0.0903, -0.5088], [0.1046, -0.5101], [0.1229, -0.514], [0.1353, -0.5183], [0.1513, -0.5251], [0.168, -0.5312], [0.21, -0.5452], [0.221, -0.5539], [0.2249, -0.559], [0.2287, -0.5626], [0.2327, -0.5645], [0.236, -0.5645], [0.2467, -0.5568], [0.2635, -0.5233], [0.3004, -0.4964], [0.3007, -0.492], [0.3544, -0.4529], [0.3287, -0.4395], [0.3628, -0.3755], [0.3746, -0.3796], [0.3828, -0.3719], [0.3821, -0.3716], [0.3827, -0.3694], [0.4495, -0.3189], [0.4803, -0.3194], [0.4781, -0.2716], [0.4911, -0.2648], [0.4907, -0.2525], [0.5, -0.2517], [0.4981, -0.215], [0.4878, -0.2086], [0.4826, -0.1964], [0.4789, -0.1836], [0.4773, -0.1782], [0.4555, -0.1792], [0.4556, -0.1703], [0.4532, -0.1611], [0.4471, -0.1457], [0.4301, -0.1031], [0.4181, -0.0729], [0.4036, -0.0371], [0.3925, -0.0086], [0.382, 0.0197], [0.3722, 0.0459], [0.3736, 0.0472], [0.3587, 0.0593], [0.2974, 0.0354], [0.3157, 0.1159], [0.2378, 0.1323], [0.2475, 0.2017], [0.2457, 0.2012], [0.2244, 0.1967], [0.2215, 0.2137], [0.2454, 0.2175], [0.2482, 0.2285], [0.2307, 0.2754], [0.2282, 0.2893], [0.234, 0.3157], [0.2535, 0.3613], [0.2602, 0.3933], [0.2585, 0.3983], [0.2762, 0.4888], [0.284, 0.5362], [0.2699, 0.5645], [0.2247, 0.5416], [0.1694, 0.5357], [0.1924, 0.4903], [0.1275, 0.4775], [0.1266, 0.4764], [0.0845, 0.1866], [0.0824, 0.1869], [0.082, 0.1882], [0.0294, 0.1654], [-0.1578, 0.291], [-0.1647, 0.2875], [-0.2019, 0.2163], [-0.1872, 0.151], [-0.1719, 0.1472], [-0.1581, 0.14], [-0.1417, 0.1229], [-0.1325, 0.1009], [-0.1313, 0.0851], [-0.1352, 0.0669], [-0.1412, 0.0559], [-0.1459, 0.049], [-0.1627, 0.034], [-0.1653, 0.0323], [-0.1693, 0.03], [-0.1846, 0.0277], [-0.1977, 0.0275], [-0.2091, 0.0291], [-0.2223, 0.034], [-0.2328, 0.0408], [-0.2427, 0.0504], [-0.2493, 0.0614], [-0.2871, 0.05], [-0.3977, 0.0066], [-0.4323, -0.0035], [-0.4345, -0.0156], [-0.4728, -0.0191], [-0.4961, -0.0278], [-0.5, -0.0419]];const ASP=1.1291;
export function initKSP(o){
 const mobile=matchMedia('(max-width:800px)').matches;
 let r;try{r=new WebGLRenderer({canvas:o.canvas,antialias:!mobile,alpha:true})}catch(e){return null}
 r.setPixelRatio(Math.min(devicePixelRatio||1,mobile?1.25:1.75));r.setClearColor(0x050505,1);
 const sc=new Scene();sc.fog=new Fog(0x050505,70,230);
 const cam=new PerspectiveCamera(50,1,.5,500);
 sc.add(new AmbientLight(0x9fb0a0,1.4));const dl=new DirectionalLight(0xffffff,1.1);dl.position.set(40,80,30);sc.add(dl);
 let s=11;const rnd=()=>{s=(s*16807)%2147483647;return s/2147483647};
 const D=new Object3D(),Y=new Vector3(0,1,0);
 const LAT=mobile?9:13,XS=mobile?12:9,YL=-1.2,YM=-1.8;
 const XWc=((LAT-1)/2)*XS+8,ZH=XWc*ASP,K=XWc*2;
 const P=POLY.map(p=>[p[0]*K,-p[1]*K]);
 const inside=(x,z)=>{let c=false;for(let i=0,j=P.length-1;i<P.length;j=i++){const a=P[i],b=P[j];if((a[1]>z)!=(b[1]>z)&&x<(b[0]-a[0])*(z-a[1])/(b[1]-a[1])+a[0])c=!c}return c};
 const xs=[];for(let i=0;i<LAT;i++)xs.push((i-(LAT-1)/2)*XS);
 const XW=xs[LAT-1]+8;
 const mat=(c,e)=>new MeshStandardMaterial({color:c,emissive:c,emissiveIntensity:e,roughness:.5,metalness:.3});
 // counts
 const cnt={pipes:0,sprk:0,bub:0,drip:0};
 // main pipe
 let mx0=-XW,mx1=XW;{let a=1e9,b=-1e9;for(let x=-XW;x<=XW;x+=1)if(inside(x,0)){a=Math.min(a,x);b=Math.max(b,x)}if(b>a){mx0=a;mx1=b}}
 const main=new Mesh(new CylinderGeometry(.9,.9,mx1-mx0,16),mat(0x2f7fd0,.5));main.rotation.z=Math.PI/2;main.position.set((mx0+mx1)/2,YM,0);sc.add(main);cnt.pipes++;
 // laterals as instanced segments
 const SEG=4,zr=xs.map(x=>{let a=1e9,b=-1e9;for(let z=-ZH;z<=ZH;z+=1)if(inside(x,z)){a=Math.min(a,z);b=Math.max(b,z)}return b>a?[a,b]:[0,0]});
 const segs=[];xs.forEach((x,i)=>{const [a,b]=zr[i];for(let z=a+SEG/2;z<=b-SEG/2+.01;z+=SEG)segs.push([x,z])});
 const lat=new InstancedMesh(new CylinderGeometry(.32,.32,SEG,8),mat(WATER,.6),segs.length);let k=0;
 segs.forEach(([x,z])=>{D.position.set(x,YL,z);D.rotation.set(Math.PI/2,0,0);D.scale.set(1,1,1);D.updateMatrix();lat.setMatrixAt(k++,D.matrix)});
 xs.forEach(x=>{const ri=new Mesh(new CylinderGeometry(.5,.5,YL-YM,8),mat(0x2f7fd0,.5));ri.position.set(x,(YL+YM)/2,0);sc.add(ri)});
 sc.add(lat);cnt.pipes+=segs.length+LAT;
 // trees, branches, bubblers, drippers
 const tp=[];xs.forEach(x=>{for(let z=-ZH+3;z<=ZH-3;z+=5){[-1,1].forEach(sd=>{if(rnd()<.12)return;if(!inside(x+sd*3,z))return;tp.push([x+sd*(2.6+rnd()*.6),z+(rnd()-.5)*1.2,sd,x])})}});
 const N=tp.length;
 const br=new InstancedMesh(new CylinderGeometry(.14,.14,1,6),mat(WATER,.5),N);
 const rs=new InstancedMesh(new CylinderGeometry(.14,.14,YL*-1,6),mat(WATER,.5),N);
 const bb=new InstancedMesh(new TorusGeometry(.5,.08,6,14),mat(LIME,.9),N);
 const trunk=new InstancedMesh(new CylinderGeometry(.2,.3,2.2,6),new MeshStandardMaterial({color:0x4a3a2a,roughness:.9}),N);
 const crown=new InstancedMesh(new SphereGeometry(1.7,10,8),new MeshStandardMaterial({color:0x2d6a3a,emissive:0x0d2a14,roughness:.8,transparent:true,opacity:.5,depthWrite:false}),N);
 const dr=new InstancedMesh(new SphereGeometry(.11,6,6),mat(LIME,1),N*4);let di=0;
 tp.forEach((t,i)=>{const [tx,tz,sd,lx]=t;
  const L=Math.abs(tx-lx);D.rotation.set(0,0,Math.PI/2);D.scale.set(1,L,1);D.position.set((tx+lx)/2,YL,tz);D.updateMatrix();br.setMatrixAt(i,D.matrix);
  D.rotation.set(0,0,0);D.scale.set(1,1,1);D.position.set(tx,YL/2-.0,tz);D.updateMatrix();rs.setMatrixAt(i,D.matrix);
  D.rotation.set(Math.PI/2,0,0);D.position.set(tx,.12,tz);D.updateMatrix();bb.setMatrixAt(i,D.matrix);
  D.rotation.set(0,0,0);D.position.set(tx,1.1,tz);D.updateMatrix();trunk.setMatrixAt(i,D.matrix);
  const sz=.55+rnd()*.35;D.scale.set(sz,sz,sz);D.position.set(tx,3.4,tz);D.updateMatrix();crown.setMatrixAt(i,D.matrix);D.scale.set(1,1,1);
  for(let q=0;q<4;q++){const a=q*Math.PI/2+.4;D.position.set(tx+Math.cos(a)*1.3,.1,tz+Math.sin(a)*1.3);D.updateMatrix();dr.setMatrixAt(di++,D.matrix)}});
 [br,rs,bb,trunk,crown,dr].forEach(m=>sc.add(m));
 cnt.pipes+=N*2;cnt.bub=N;cnt.drip=N*4;
 // sprinklers between laterals
 const sp=[];for(let i=0;i<LAT;i++){for(let z=-ZH+6;z<=ZH-6;z+=9){if(!inside(xs[i]+XS*.5,z))continue;sp.push([xs[i]+(i%2?-1:1)*XS*.5*0+XS*.5-.0,z])}}
 const sH=new InstancedMesh(new CylinderGeometry(.22,.22,1,8),mat(0xe9eef5,.4),sp.length);
 const sB=new InstancedMesh(new CylinderGeometry(.14,.14,1,6),mat(WATER,.5),sp.length);
 sp.forEach((p,i)=>{const lx=p[0]-XS*.5;D.rotation.set(0,0,0);D.scale.set(1,.9,1);D.position.set(p[0],.45,p[1]);D.updateMatrix();sH.setMatrixAt(i,D.matrix);
  D.rotation.set(0,0,Math.PI/2);D.scale.set(1,XS*.5,1);D.position.set(lx+XS*.25,YL,p[1]);D.updateMatrix();sB.setMatrixAt(i,D.matrix);
  D.rotation.set(0,0,0);D.scale.set(1,1,1);D.position.set(p[0],(YL+.2)/2,p[1]);D.scale.set(1,(.2-YL)/1,1);D.updateMatrix();});
 sc.add(sH,sB);cnt.sprk=sp.length;cnt.pipes+=sp.length;
 // ground
 const gm=new MeshStandardMaterial({color:0x0f1a12,transparent:true,opacity:.9,roughness:1,side:DoubleSide,depthWrite:false});
 const shp=new Shape();P.forEach((p,i)=>{const px=p[0],py=-p[1];i?shp.lineTo(px,py):shp.moveTo(px,py)});
 const ground=new Mesh(new ShapeGeometry(shp),gm);ground.rotation.x=-Math.PI/2;sc.add(ground);
 const olm=new LineBasicMaterial({color:LIME,transparent:true,opacity:.9});
 const outl=new Line(new BufferGeometry().setFromPoints(P.concat([P[0]]).map(p=>new Vector3(p[0],.15,p[1]))),olm);sc.add(outl);
 const grid={material:{opacity:0,transparent:true}};
 // water flow particles
 const FP=mobile?500:1400,fp=new Float32Array(FP*3),fm=[];
 for(let i=0;i<FP;i++){fm.push({l:Math.floor(rnd()*LAT),t:rnd(),d:rnd()<.5?-1:1,v:.15+rnd()*.15,ph:rnd()})}
 const fg=new BufferGeometry();fg.setAttribute('position',new Float32BufferAttribute(fp,3));
 sc.add(new Points(fg,new PointsMaterial({color:0xbfeaff,size:.45,transparent:true,opacity:.95,blending:AdditiveBlending,depthWrite:false})));
 // spray droplets
 const PER=mobile?4:7,SP=sp.length*PER,sa=new Float32Array(SP*3),sg=new BufferGeometry();sg.setAttribute('position',new Float32BufferAttribute(sa,3));
 sc.add(new Points(sg,new PointsMaterial({color:0x9fe0ff,size:.28,transparent:true,opacity:.85,blending:AdditiveBlending,depthWrite:false})));
 const dir=sp.map(()=>rnd()*6.28);
 function size(){const w=o.host.clientWidth||innerWidth,h=o.host.clientHeight||innerHeight;r.setSize(w,h,false);cam.aspect=w/h;cam.fov=w/h<1?68:50;cam.updateProjectionMatrix()}
 size();addEventListener('resize',size);
 let run=false,cur=0;const sm=MathUtils.smoothstep,tg=new Vector3();
 function frame(t){
  if(!run)return;requestAnimationFrame(frame);
  const p=o.progress();cur+=(p-cur)*.06;const T=t*.001;
  // particles
  for(let i=0;i<FP;i++){const f=fm[i];f.t=(f.t+f.v*.004)%1;const lx=xs[f.l];
   if(f.t<.35){const u=f.t/.35;fp[i*3]=lx*u;fp[i*3+1]=YM+(YL-YM)*0;fp[i*3+2]=0;fp[i*3+1]=YM}
   else{const u=(f.t-.35)/.65;fp[i*3]=lx;fp[i*3+1]=YL+(f.ph-.5)*.3;fp[i*3+2]=f.d>0?zr[f.l][1]*u:zr[f.l][0]*u}}
  fg.attributes.position.needsUpdate=true;
  for(let i=0;i<sp.length;i++)for(let q=0;q<PER;q++){const ph=((T*.9+q/PER+i*.13)%1),a=dir[i]+q*(6.28/PER),R=ph*3.6,h=Math.sin(ph*Math.PI)*2.6+.5,j=(i*PER+q)*3;sa[j]=sp[i][0]+Math.cos(a)*R;sa[j+1]=h;sa[j+2]=sp[i][1]+Math.sin(a)*R}
  sg.attributes.position.needsUpdate=true;
  // camera: aerial -> cutaway underground fly
  const a=-.6+cur*2.4,rad=165-cur*95,hgt=105-sm(cur,0,.8)*92;
  tg.set(Math.sin(cur*3)*8,sm(cur,.2,1)*-1.2,Math.sin(cur*5)*6);
  cam.position.set(Math.sin(a)*rad,hgt,Math.cos(a)*rad*.8);cam.lookAt(tg);
  gm.opacity=.92-sm(cur,.15,.55)*.82;olm.opacity=.9*(1-sm(cur,.5,.9)*.6);
  crown.visible=trunk.visible=cur<.7||true;
  r.render(sc,cam);o.onFrame&&o.onFrame(cur);
 }
 return {stats:cnt,start(){if(!run){run=true;requestAnimationFrame(frame)}},stop(){run=false},renderOnce(){run=true;frame(0);run=false}};
}
