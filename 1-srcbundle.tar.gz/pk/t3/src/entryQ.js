import {initModel} from './model_qtc.js';window.initQTC=initModel;
