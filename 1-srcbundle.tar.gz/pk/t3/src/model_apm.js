import {WebGLRenderer,Scene,PerspectiveCamera,Fog,Color,HemisphereLight,DirectionalLight,MeshStandardMaterial,MeshBasicMaterial,MeshLambertMaterial,Mesh,BufferGeometry,BufferAttribute,Float32BufferAttribute,Vector3,Plane,SphereGeometry,PlaneGeometry,BackSide,DoubleSide,CatmullRomCurve3,PMREMGenerator,MathUtils,LineSegments,WireframeGeometry,LineBasicMaterial} from 'three';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
// local origin (metres, relative to model min corner) and path, east/north/elevation
const OX=500,OY=550;
const PATH=window.__PATH||[[-470,-380,150],[-330,-260,70],[-200,-150,26],[-80,-60,15],[40,20,11.5],[170,100,11],[300,185,11.5],[420,290,12.5]];
const NAV={ground:0x7a8aa8,storm:0x52a67d,pressure:0x00ff00,water:0xbf00ff,equipment:0xffffff,structure:0x52a67d};
const REAL={storm:[0xd4d7d8,.7,0],pressure:[0x2f7d57,.45,.55],water:[0x1f6fd1,.4,.1],equipment:[0xc2453a,.35,.7],structure:[0xbfc2c0,.8,0]};
export async function initModel(o){
 const mobile=matchMedia('(max-width:800px)').matches;
 let r;try{r=new WebGLRenderer({canvas:o.canvas,antialias:!mobile,alpha:false})}catch(e){return null}
 r.setPixelRatio(Math.min(devicePixelRatio||1,mobile?1.25:1.6));r.localClippingEnabled=true;
 const sc=new Scene();const cam=new PerspectiveCamera(55,1,.3,9000);
 const pm=new PMREMGenerator(r);sc.environment=pm.fromScene(new RoomEnvironment(),.04).texture;sc.environmentIntensity=.55;
 const pl=new Plane(),nl=new Plane();
 // sky domes (nav: dark engineering gradient, real: daylight)
 function dome(top,bot,clip){const g=new SphereGeometry(6000,24,16),c=[];const p=g.attributes.position;const ct=new Color(top),cb=new Color(bot),t=new Color();
  for(let i=0;i<p.count;i++){const k=MathUtils.clamp((p.getY(i)/6000+.15)/.9,0,1);t.copy(cb).lerp(ct,Math.pow(k,.7));c.push(t.r,t.g,t.b)}
  g.setAttribute('color',new Float32BufferAttribute(c,3));
  const m=new Mesh(g,new MeshBasicMaterial({vertexColors:true,side:BackSide,fog:false,depthWrite:false,clippingPlanes:[clip]}));m.renderOrder=-10;sc.add(m);return m}
 dome(0x2c3a52,0x0b0f16,nl);const sky=dome(0x5f9bd6,0xdfe9f2,pl);
 sc.fog=new Fog(0xb4c2cc,120,1100);
 sc.add(new HemisphereLight(0xdfeeff,0x6b5a45,.9));const sun=new DirectionalLight(0xfff1d6,2.2);sun.position.set(-400,700,300);sc.add(sun);
 const buf=await (await fetch(o.url)).arrayBuffer();
 const b8=new Uint8Array(buf);const raw=(b8[0]===0x1f&&b8[1]===0x8b)?new Uint8Array(await new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer()):b8;
 const dv=new DataView(raw.buffer);const hl=dv.getUint32(0,true);const H=JSON.parse(new TextDecoder().decode(raw.subarray(4,4+hl)));
 let off=4+hl;const mn=H.min,ex=[H.max[0]-H.min[0],H.max[1]-H.min[1],H.max[2]-H.min[2]];
 const stats={tris:0,objs:H.objs||0};const groups={};
 for(const g of H.groups){
  const nvb=g.nv*6,ntb=g.nt*12;const pv=new Uint16Array(raw.buffer.slice(raw.byteOffset+off,raw.byteOffset+off+nvb));off+=nvb;
  const ix=new Uint32Array(raw.buffer.slice(raw.byteOffset+off,raw.byteOffset+off+ntb));off+=ntb;
  const pos=new Float32Array(g.nv*3);
  for(let i=0;i<g.nv;i++){const x=pv[i*3]/65535*ex[0]-OX,n=pv[i*3+1]/65535*ex[1]-OY,z=pv[i*3+2]/65535*ex[2];pos[i*3]=x;pos[i*3+1]=z;pos[i*3+2]=-n}
  const geo=new BufferGeometry();geo.setAttribute('position',new BufferAttribute(pos,3));geo.setIndex(new BufferAttribute(ix,1));geo.computeVertexNormals();
  stats.tris+=g.nt;groups[g.name]=geo;
 }
 const meshes=[];
 {const pg=new (PlaneGeometry)(24000,24000);pg.rotateX(-Math.PI/2);const soil=new Mesh(pg,new MeshStandardMaterial({color:0x6b5640,roughness:1,clippingPlanes:[pl]}));soil.position.y=0;sc.add(soil);
  const ns=new Mesh(pg,new MeshBasicMaterial({color:0x0b1019,fog:false,clippingPlanes:[nl]}));ns.position.y=0;sc.add(ns)}
 for(const [name,geo] of Object.entries(groups)){
  if(name==='ground'){
   // nav: wire grid; real: translucent earth with colour noise
   const nf=new Mesh(geo,new MeshBasicMaterial({color:0x26324a,transparent:true,opacity:.55,fog:false,side:DoubleSide,depthWrite:false,clippingPlanes:[nl]}));nf.renderOrder=2;sc.add(nf);
   const p=geo.attributes.position,c=new Float32Array(p.count*3),a=new Color(0x4f7035),b=new Color(0x7a6038),t=new Color();
   for(let i=0;i<p.count;i++){const n=(Math.sin(p.getX(i)*.013)+Math.sin(p.getZ(i)*.021+1.3)+Math.sin((p.getX(i)+p.getZ(i))*.007))/3*.5+.5;t.copy(a).lerp(b,n);c[i*3]=t.r;c[i*3+1]=t.g;c[i*3+2]=t.b}
   geo.setAttribute('color',new BufferAttribute(c,3));
   const m=new Mesh(geo,new MeshStandardMaterial({vertexColors:true,roughness:1,transparent:true,opacity:.3,side:DoubleSide,depthWrite:false,clippingPlanes:[pl],flatShading:true}));m.renderOrder=2;sc.add(m);meshes.push(m);continue}
  const nav=new Mesh(geo,new MeshLambertMaterial({color:NAV[name],fog:false,clippingPlanes:[nl],emissive:NAV[name],emissiveIntensity:.35}));sc.add(nav);
  const [col,ro,me]=REAL[name];
  const re=new Mesh(geo,new MeshStandardMaterial({color:col,roughness:ro,metalness:me,flatShading:true,clippingPlanes:[pl]}));sc.add(re);
 }
 // path
 const curve=new CatmullRomCurve3(PATH.map(p=>new Vector3(p[0],p[2],-p[1])),false,'centripetal');
 const look=new Vector3(),pos=new Vector3(),fw=new Vector3(),rt=new Vector3(),up=new Vector3(0,1,0);
 function size(){const w=o.host.clientWidth||innerWidth,h=o.host.clientHeight||innerHeight;r.setSize(w,h,false);cam.aspect=w/h;cam.fov=w/h<1?75:55;cam.updateProjectionMatrix()}
 size();addEventListener('resize',size);
 let run=false,cur=0;const sm=MathUtils.smoothstep;
 function frame(){
  if(!run)return;requestAnimationFrame(frame);
  const p=window.__P!=null?window.__P:o.progress();cur+=(p-cur)*.08;if(window.__P!=null)cur=p;
  const u=MathUtils.clamp(cur,0,.999);
  curve.getPointAt(u,pos);curve.getPointAt(Math.min(.999,u+.035),look);look.y-=7+60*(1-sm(u,0,.22));
  if(window.__CAM){const c=window.__CAM;pos.set(c[0],c[1],c[2]);look.set(c[3],c[4],c[5])}
  pos.y+=Math.sin(u*9)*.6;cam.position.copy(pos);cam.lookAt(look);cam.updateMatrixWorld();
  // wipe: nav -> real, left to right
  const w=sm(cur,.28,.58);const a=(-1.2+2.4*w)*Math.tan(MathUtils.degToRad(cam.fov/2))*cam.aspect;
  cam.getWorldDirection(fw);rt.crossVectors(fw,up).normalize();
  const n=rt.clone().addScaledVector(fw,-a).normalize();
  nl.setFromNormalAndCoplanarPoint(n,pos);pl.setFromNormalAndCoplanarPoint(n.clone().negate(),pos);
  // plane keeps >=0 side: real = left of line => normal points left
  if(o.onFrame)o.onFrame(cur,w);
  r.render(sc,cam);
 }
 return {stats,start(){if(!run){run=true;requestAnimationFrame(frame)}},stop(){run=false},renderOnce(){run=true;frame();run=false}};
}
