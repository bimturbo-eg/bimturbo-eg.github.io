import {WebGLRenderer,Scene,PerspectiveCamera,Fog,Color,HemisphereLight,DirectionalLight,MeshStandardMaterial,MeshBasicMaterial,MeshLambertMaterial,Mesh,BufferGeometry,BufferAttribute,Float32BufferAttribute,Vector3,Plane,SphereGeometry,PlaneGeometry,BackSide,DoubleSide,CatmullRomCurve3,PMREMGenerator,MathUtils,ACESFilmicToneMapping,CanvasTexture,RepeatWrapping,LineSegments,WireframeGeometry,LineBasicMaterial} from 'three';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
// local origin (metres, relative to model min corner) and path, east/north/elevation
const OX=738,OY=1292;const gz=()=>8.96;
const PATH=window.__PATH||[[549,-1367,129.0],[475,-1247,54.0],[434,-1179,16.0],[243,-869,16.0],[217,-616,16.0],[202,-366,16.0],[123,-121,16.0],[2,131,16.0],[-151,395,16.0],[-291,641,16.0],[-372,877,16.0],[-405,1107,16.0]];
const REAL={cable:[0x1b1b1f,.35,0],hv:[0x9c1c1c,.35,0],duct:[0x908d85,.9,0],pipe:[0x7f8d96,.5,.2],structure:[0xa5a29a,.85,0],mv:[0xb3261e,.4,0],light:[0x3c3f44,.45,.4],water:[0x1f5fa8,.4,.1],irrig:[0x2f8f4a,.5,0],tele:[0x7a3ea0,.45,0],storm:[0x8a8f93,.8,0],sewer:[0x6b5a45,.8,0],traffic:[0xd9a521,.5,0],cw:[0x4f7a9a,.5,.1],other:[0x9a978f,.85,0]};
export async function initModel(o){
 const mobile=matchMedia('(max-width:800px)').matches;
 let r;try{r=new WebGLRenderer({canvas:o.canvas,antialias:!mobile,alpha:false})}catch(e){return null}
 r.setPixelRatio(Math.min(devicePixelRatio||1,mobile?1.25:1.6));r.localClippingEnabled=true;r.toneMapping=ACESFilmicToneMapping;r.toneMappingExposure=.72;if(window.__SH){r.shadowMap.enabled=true;r.shadowMap.type=2}
 const sc=new Scene();const cam=new PerspectiveCamera(55,1,.3,9000);
 const pm=new PMREMGenerator(r);sc.environment=pm.fromScene(new RoomEnvironment(),.04).texture;sc.environmentIntensity=.3;
 const pl=new Plane(),nl=new Plane();
 // sky domes (nav: dark engineering gradient, real: daylight)
 function dome(top,bot,clip){const g=new SphereGeometry(6000,24,16),c=[];const p=g.attributes.position;const ct=new Color(top),cb=new Color(bot),t=new Color();
  for(let i=0;i<p.count;i++){const k=MathUtils.clamp((p.getY(i)/6000+.15)/.9,0,1);t.copy(cb).lerp(ct,Math.pow(k,.7));c.push(t.r,t.g,t.b)}
  g.setAttribute('color',new Float32BufferAttribute(c,3));
  const m=new Mesh(g,new MeshBasicMaterial({vertexColors:true,side:BackSide,fog:false,depthWrite:false,clippingPlanes:[clip]}));m.renderOrder=-10;sc.add(m);return m}
 dome(0x2c3a52,0x0b0f16,nl);const sky=dome(0x5f9bd6,0xdfe9f2,pl);
 sc.fog=new Fog(0xcfc4ac,160,1700);
 sc.add(new HemisphereLight(0xdfeeff,0x6b5a45,.45));const sun=new DirectionalLight(0xfff0d0,3.4);sun.position.set(-400,700,300);sc.add(sun);sc.add(sun.target);if(window.__SH){sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);const sc2=sun.shadow.camera;sc2.left=-110;sc2.right=110;sc2.top=110;sc2.bottom=-110;sc2.near=10;sc2.far=2000;sun.shadow.bias=-.0004;sun.shadow.normalBias=.3}
 const buf=await (await fetch(o.url)).arrayBuffer();
 const b8=new Uint8Array(buf);const raw=(b8[0]===0x1f&&b8[1]===0x8b)?new Uint8Array(await new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer()):b8;
 const dv=new DataView(raw.buffer);const hl=dv.getUint32(0,true);const H=JSON.parse(new TextDecoder().decode(raw.subarray(4,4+hl)));
 let off=4+hl;const mn=H.min,ex=[H.max[0]-H.min[0],H.max[1]-H.min[1],H.max[2]-H.min[2]];
 const stats={tris:0,objs:H.objs||0};const groups={};
 for(const g of H.groups){
  const nvb=g.nv*6,ntb=g.nt*12;const pv=new Uint16Array(raw.buffer.slice(raw.byteOffset+off,raw.byteOffset+off+nvb));off+=nvb;
  const ix=new Uint32Array(raw.buffer.slice(raw.byteOffset+off,raw.byteOffset+off+ntb));off+=ntb;
  const pos=new Float32Array(g.nv*3);
  for(let i=0;i<g.nv;i++){const x=pv[i*3]/65535*ex[0]-OX,n=pv[i*3+1]/65535*ex[1]-OY,z=pv[i*3+2]/65535*ex[2];pos[i*3]=x;pos[i*3+1]=z;pos[i*3+2]=-n}
  const geo=new BufferGeometry();geo.setAttribute('position',new BufferAttribute(pos,3));geo.setIndex(new BufferAttribute(ix,1));geo.computeVertexNormals();
  stats.tris+=g.nt;groups[g.name+'|'+g.color]=geo;
 }
 const meshes=[];
 {const pg=new PlaneGeometry(24000,24000);pg.rotateX(-Math.PI/2);const soil=new Mesh(pg,new MeshStandardMaterial({color:0x7a6347,roughness:1,clippingPlanes:[pl]}));soil.position.y=-1.8;sc.add(soil);
  const ns=new Mesh(pg,new MeshBasicMaterial({color:0x0b1019,fog:false,clippingPlanes:[nl]}));ns.position.y=-1.8;sc.add(ns)}
 for(const [key,geo] of Object.entries(groups)){
  const [name,hx]=key.split('|');const ncol=parseInt(hx,16)||0x8899aa;
  const nav=new Mesh(geo,new MeshLambertMaterial({color:ncol,fog:false,clippingPlanes:[nl],emissive:ncol,emissiveIntensity:.45}));sc.add(nav);
  const [col,ro,me]=REAL[name]||REAL.duct;
  const tint=new Color(col);if(name==='cable'){tint.lerp(new Color(ncol),.22)}
  const re=new Mesh(geo,new MeshStandardMaterial({color:tint,roughness:ro,metalness:me,flatShading:name!=='cable',clippingPlanes:[pl]}));if(window.__SH){re.castShadow=true;re.receiveShadow=true}sc.add(re);
 }
 // ground strip following the road, sand texture (real) / dark slab (nav)
 {const cv=document.createElement('canvas');cv.width=cv.height=256;const x=cv.getContext('2d');x.fillStyle='#c8b189';x.fillRect(0,0,256,256);
  for(let i=0;i<5000;i++){const v=150+Math.random()*90|0;x.fillStyle='rgba('+v+','+(v-18)+','+(v-55)+','+(.25+Math.random()*.35)+')';x.fillRect(Math.random()*256,Math.random()*256,1+Math.random()*2,1+Math.random()*2)}
  const tx=new CanvasTexture(cv);tx.wrapS=tx.wrapT=RepeatWrapping;tx.repeat.set(110,110);tx.anisotropy=4;
  const gg=new PlaneGeometry(4400,4400,1,1);gg.rotateX(-Math.PI/2);const p=gg.attributes.position;
  for(let i=0;i<p.count;i++){const yr=OY-p.getZ(i);p.setY(i,gz(yr)+Math.sin(p.getX(i)*.05+yr*.03)*.15)}
  gg.translate(0,0,-0);gg.computeVertexNormals();
  const gp=new Mesh(gg,new MeshStandardMaterial({map:tx,roughness:1,transparent:true,opacity:.3,side:DoubleSide,depthWrite:false,clippingPlanes:[pl]}));gp.position.set(0,0,-(1100-1250+100));gp.renderOrder=2;sc.add(gp);
  const gn=new Mesh(gg,new MeshBasicMaterial({color:0x26324a,transparent:true,opacity:.5,fog:false,side:DoubleSide,depthWrite:false,clippingPlanes:[nl]}));gn.position.copy(gp.position);gn.renderOrder=2;sc.add(gn)}
 // path
 const curve=new CatmullRomCurve3(PATH.map(p=>new Vector3(p[0],p[2],-p[1])),false,'centripetal');
 const look=new Vector3(),pos=new Vector3(),fw=new Vector3(),rt=new Vector3(),up=new Vector3(0,1,0);
 function size(){const w=o.host.clientWidth||innerWidth,h=o.host.clientHeight||innerHeight;r.setSize(w,h,false);cam.aspect=w/h;cam.fov=w/h<1?75:55;cam.updateProjectionMatrix()}
 size();addEventListener('resize',size);
 let run=false,cur=0;const sm=MathUtils.smoothstep;
 function frame(){
  if(!run)return;requestAnimationFrame(frame);
  const p=window.__P!=null?window.__P:o.progress();cur+=(p-cur)*.08;if(window.__P!=null)cur=p;
  const u=MathUtils.clamp(cur,0,.999);
  curve.getPointAt(u,pos);curve.getPointAt(Math.min(.999,u+.02),look);look.y-=11+50*(1-sm(u,0,.22));
  if(window.__CAM){const c=window.__CAM;pos.set(c[0],c[1],c[2]);look.set(c[3],c[4],c[5])}
  pos.y+=Math.sin(u*9)*.6;if(window.__SH){sun.target.position.set(pos.x,0,pos.z);sun.position.set(pos.x-300,500,pos.z+200)}cam.position.copy(pos);cam.lookAt(look);cam.updateMatrixWorld();
  // wipe: nav -> real, left to right
  const w=window.__W!=null?window.__W:sm(cur,.28,.58);const a=(-1.2+2.4*w)*Math.tan(MathUtils.degToRad(cam.fov/2))*cam.aspect;
  cam.getWorldDirection(fw);rt.crossVectors(fw,up).normalize();
  const n=rt.clone().addScaledVector(fw,-a).normalize();
  nl.setFromNormalAndCoplanarPoint(n,pos);pl.setFromNormalAndCoplanarPoint(n.clone().negate(),pos);
  // plane keeps >=0 side: real = left of line => normal points left
  if(o.onFrame)o.onFrame(cur,w);
  r.render(sc,cam);
 }
 return {stats,start(){if(!run){run=true;requestAnimationFrame(frame)}},stop(){run=false},renderOnce(){run=true;frame();run=false}};
}
