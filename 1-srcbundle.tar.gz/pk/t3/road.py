import numpy as np
from PIL import Image
from scipy import ndimage as ndi
raw=np.array(Image.open('mask_raw.png'))>0
S=2
m=np.array(Image.fromarray((raw*255).astype(np.uint8)).resize((raw.shape[1]*S,raw.shape[0]*S),Image.BILINEAR)).astype(np.float32)/255
m=ndi.gaussian_filter(m,7*S/2)>0.5
m=ndi.binary_opening(m,structure=np.ones((9,9))).astype(np.uint8)
lab,n=ndi.label(m)
sz=ndi.sum(m,lab,range(1,n+1))
m=np.isin(lab,[i+1 for i,v in enumerate(sz) if v>4000*S*S]).astype(np.uint8)
# Zhang-Suen
def zs(img):
    img=img.copy().astype(np.uint8)
    ch=True
    while ch:
        ch=False
        for step in (0,1):
            p=np.pad(img,1)
            P2=p[:-2,1:-1];P3=p[:-2,2:];P4=p[1:-1,2:];P5=p[2:,2:];P6=p[2:,1:-1];P7=p[2:,:-2];P8=p[1:-1,:-2];P9=p[:-2,:-2]
            nb=[P2,P3,P4,P5,P6,P7,P8,P9]
            B=sum(x.astype(int) for x in nb)
            A=sum(((nb[i]==0)&(nb[(i+1)%8]==1)).astype(int) for i in range(8))
            if step==0: c=(P2*P4*P6==0)&(P4*P6*P8==0)
            else: c=(P2*P4*P8==0)&(P2*P6*P8==0)
            d=(img==1)&(B>=2)&(B<=6)&(A==1)&c
            if d.any(): img[d]=0;ch=True
    return img
# skeleton on half-res for speed
sk=zs(m[::2,::2].copy()).astype(np.uint8)
# prune spurs
def nbc(s):
    return ndi.convolve(s.astype(np.int32),np.ones((3,3),np.int32),mode='constant')-s
for it in range(40):
    e=(sk==1)&(nbc(sk)<=1)
    # only remove endpoints belonging to short branches: approximate by removing 40 iterations then regrow endpoints
    sk[e]=0
sk0=sk.copy()
# regrow: dilate conditional within original skeleton not possible; accept slight shortening (40px at half res =~ 20 m... )
skf=np.kron(sk,np.ones((2,2),np.uint8))[:m.shape[0],:m.shape[1]]
np.save('sk.npy',skf);np.save('m2.npy',m)
print(m.shape,sk.sum())
