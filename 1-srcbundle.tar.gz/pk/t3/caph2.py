import subprocess,json,time,urllib.request,websocket,base64,sys
wd,ht=int(sys.argv[1]),int(sys.argv[2]);outs=sys.argv[3:]  # name=hashstring
p=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--no-sandbox','--disable-dev-shm-usage','--remote-allow-origins=*','--remote-debugging-port=9229','--user-data-dir=/tmp/chrome-t','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--enable-webgl','about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
for _ in range(40):
 try: tabs=json.load(urllib.request.urlopen('http://127.0.0.1:9229/json'));break
 except: time.sleep(.2)
w=websocket.create_connection(tabs[0]['webSocketDebuggerUrl'],max_size=None);i=0
def call(m,a={}):
 global i
 i+=1;w.send(json.dumps({'id':i,'method':m,'params':a}))
 while 1:
  r=json.loads(w.recv())
  if r.get('id')==i:return r.get('result',r)
def ev(s):return call('Runtime.evaluate',{'expression':s,'returnByValue':True,'awaitPromise':True}).get('result',{}).get('value')
call('Runtime.enable');call('Emulation.setDeviceMetricsOverride',{'width':wd,'height':ht,'deviceScaleFactor':1,'mobile':wd<600})
for o in outs:
 n,h=o.split('=',1)
 call('Page.navigate',{'url':'http://127.0.0.1:8765/th2.html#'+h});time.sleep(.5);call('Page.reload')
 for _ in range(60):
  time.sleep(1)
  if (ev('document.title') or '').startswith(('ready','ERR')):break
 time.sleep(1);ev('window.A.renderOnce()')
 r=call('Page.captureScreenshot',{'format':'jpeg','quality':72});open('/downloads/h2-%s.jpg'%n,'wb').write(base64.b64decode(r['data']));print(n,ev('document.title'),ev('JSON.stringify(window.__PC)'))
p.terminate()
